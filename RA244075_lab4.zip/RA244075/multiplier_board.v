module multiplier_board (
	input [9:0] SW,
	input CLOCK_50,
	input [3:0] KEY,
	output [6:0] HEX2,
	output [6:0] HEX1,
	output [6:0] HEX0
);

wire [11:0] out_r;


multiplier multiplier1 (
	.clk(CLOCK_50),
	.set(KEY[3]),
	.a(SW[9:5]),
	.b(SW[4:0]),
	.r(out_r)
);

display display1 (
	.abs_val(out_r[3:0]),
	.segs(HEX0)
);

display display2 (
	.abs_val(out_r[7:4]),
	.segs(HEX1)
);

display display3 (
	.abs_val(out_r[11:8]),
	.segs(HEX2)
);

endmodule