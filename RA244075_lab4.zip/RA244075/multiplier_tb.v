`timescale 10ns / 10ps

module multiplier_tb;

  parameter N = 4;

  // Entradas
  reg [N-1:0] a;
  reg [N-1:0] b;
  reg clk;
  reg set;

  // Saída
  wire [2*N-1:0] r;
  
  integer max_val;
  integer bits;
  integer i;
  integer f;

  // Instancia o módulo DUT (Device Under Test)
  multiplier #(N) uut (  // INSTANCIAR AQUI O MODULO A SER TESTADO
    .a(a),
    .b(b),
    .clk(clk),
    .set(set),
    .r(r)
  );

  // Clock gerado manualmente
  always #5 clk = ~clk; // Clock com período de 10ns

  initial begin
    // Inicialização
	 
    clk = 0;
    set = 0;
    a = 0;
    b = 0;

    $monitor("Time=%0t | clk=%b | set=%b | a=%d | b=%d | r=%d", $time, clk, set, a, b, r);

    // Teste 1: 3 * 2
    #10;
    a = 4'd3;
    b = 4'd2;
    set = 1;
    #10;
    set = 0;

    // Teste 2: 7 * 5
    #20;
    a = 4'd7;
    b = 4'd5;
    set = 1;
    #10;
    set = 0;

    // Teste 3: 15 * 15 (maior valor possível com 4 bits)
    #20;
    a = 4'd15;
    b = 4'd15;
    set = 1;
    #10;
    set = 0;

    // Teste 4: 0 * qualquer coisa
    #20;
    a = 4'd0;
    b = 4'd12;
    set = 1;
    #10;
    set = 0;

    // Teste 5: 6 * 8
    #20;
    a = 4'd6;
    b = 4'd8;
    set = 1;
    #10;
    set = 0;
	 
	 //Fazendo testes em massa: apenas para N <= 12 ( se nao fica muito grande, e demora par fazer a simulacao )
		bits = N;
		if (N > 12) begin
			 bits = 12;
		end

		max_val = 1 << N; // 2^N

		for (i = 0; i < max_val; i = i + 1) begin
			 for (f = 0; f < max_val; f = f + 1) begin
				  a = i[N-1:0]; // Trunca ou encaixa valor na largura N
				  b = f[N-1:0];
				  set = 1;
				  #10;
				  set = 0;
				  #10; // esperar resultado
			 end
		end
	

    // Finaliza a simulação
    #30;
    $finish;
  end

endmodule