module multiplier (
    input wire clk,
    input wire set,
    input wire [N-1:0] a,
    input wire [N-1:0] b,
    output reg [2*N-1:0] r
);
	 parameter N = 5;

    // Registradores internos
    reg [2*N-1:0] a_reg = 0;
    reg [N-1:0] b_reg = 0;
    reg [N-1:0] count = 0;
    reg running = 0;  // flag para indicar se está no meio da multiplicação

    always @(posedge clk) begin
        if (!set && !running) begin
            // Início da operação
            a_reg <= {{N{1'b0}}, a}; // estende para 2N bits
            b_reg <= b;
            r <= 0;
            count <= 0;
            running <= 1;
        end else if (running) begin
            // Executa um ciclo de multiplicação
            if (b_reg[0] == 1) begin
                r <= r + a_reg;
            end

            a_reg <= a_reg << 1;
            b_reg <= b_reg >> 1;
            count <= count + 1;

            if (count == N - 1) begin
                running <= 0;  // fim da multiplicação
            end
        end
    end

endmodule