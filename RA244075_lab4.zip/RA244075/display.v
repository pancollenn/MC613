module display (
    input  [3:0] abs_val,   // valor de 0 a 15
    output [6:0] segs       // a = seg[6], g = seg[0]
);

// 7-segment decoder (Common Cathode: 0 = ON, 1 = OFF)
assign segs = 
    (abs_val == 4'd0)  ? ~7'b0111111 : // 0
    (abs_val == 4'd1)  ? ~7'b0000110 : // 1
    (abs_val == 4'd2)  ? ~7'b1011011 : // 2
    (abs_val == 4'd3)  ? ~7'b1001111 : // 3
    (abs_val == 4'd4)  ? ~7'b1100110 : // 4
    (abs_val == 4'd5)  ? ~7'b1101101 : // 5
    (abs_val == 4'd6)  ? ~7'b1111101 : // 6
    (abs_val == 4'd7)  ? ~7'b0000111 : // 7
    (abs_val == 4'd8)  ? ~7'b1111111 : // 8
    (abs_val == 4'd9)  ? ~7'b1101111 : // 9
    (abs_val == 4'd10) ? ~7'b1110111 : // A
    (abs_val == 4'd11) ? ~7'b1111100 : // B
    (abs_val == 4'd12) ? ~7'b0111001 : // C
    (abs_val == 4'd13) ? ~7'b1011110 : // D
    (abs_val == 4'd14) ? ~7'b1111001 : // E
    (abs_val == 4'd15) ? ~7'b1110001 : // F
                         7'b1111111;   // OFF (default)
endmodule
