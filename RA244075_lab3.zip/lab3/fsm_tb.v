`timescale 10ns / 10ps

module fsm_tb;
  // Entradas
  reg clk, rst, r50, r100, r200;
  
  //saidas
  wire cafe, t50, t100, t200;
  wire [3:0] out;
  wire [3:0] state;
  

  // Instanciando o módulo fsm
  fsm mod1 (
    .clk(clk),
    .rst(rst),
    .r50(r50),
    .r100(r100),
    .r200(r200),
    .cafe(cafe),
    .t50(t50),
	 .t100(t100),
	 .t200(t200),
	 .out(out),
	 .state(state)
  );
  
  integer i;
  always #5 clk = ~clk;
  // Inicializando o testbench
  initial begin
  
	 $monitor("clk = %b, rst = %b, r50 = %b , r100 = %b, r200 = %b -> cafe = %b, t50 = %b, t100 = %b, t200 = %b, out = %b, state = %b", clk, rst, r50, r100, r200, cafe, t50, t100, t200, out, state);
    // Exibindo os resultados no console
	 clk = 0;
	 rst = 0;
	 r50 = 0;
	 r100 = 0;
	 r200 = 0;
	 
	 //simulando A compra de cafe fbgvouçsab vr
	 //simulando venda de cafe 2 de 1 real, uma de 50 centavos
    
	 r50 = 1;
	 
	 #10;
	 
	 r50 = 0;
	 
	 #10;
	 r200 = 1;
	 
	 #10;
	 // segunda moeda de 1 real
	 
	 #10;
	 
	 r100 = 0;
	 #10;
	 
	 rst = 1;
	 #10;
	 
	 #10;
	 
	 #10;
	 
	 // simulando com 1 moeda de 2 reais e 1 de 50 centavos
	 r200 = 1;
	 #10;
	 
	
	 
	 r200 = 0;
	 #10;
	 
	
	 r50 = 1;
	 
	 
	 #10;
	 
	 r50 = 0;
	 #10;
	 
	
	 
	 rst = 1;
	 #10;
	 
	 #10;
	 
	 // 5 de 50 centavos
	 
	 for ( i =0; i < 5; i= i + 1) begin
		r50 = 1;
		#10;
		
	 end
	 // resetando
	 r50 = 0;
	 #10;
	 rst = 1;
	 
	 #10;
	 
	 rst = 0;
	 
	 #10;
	 
	 #10;
	 
	 
	 
	 
	 // 3 de 50 cents, 1 de 1 real
	 
	 for ( i =0; i < 3; i = i + 1) begin
		r50 = 1;
		#10;
		
	 end
	 // moeda de 1 real
	 r50 = 0;
	 r100 = 1;
	 #10;
	 
	 
	 
	 //resetando
	 #10;
	 rst = 1;
	 r100 = 0;
	 
	 #10;
	 
	 rst = 0;
	 
	 #10;
	 
	 #10;
	 
	 
	 
	 // simulando compras que dao mais que 2,50
	 
	 // 2 de 2 reais
	 for ( i =0; i < 5; i = i + 1) begin
		r200 = 1;
		#10;
		
	 end
	 
	 r200 = 0;
	 #10;
	 rst = 1;
	 
	 
	 #10;
	 rst = 0;
	 
	 #10;
	 
	 #10;
	 
	 // 2 reais e 1 real
	#10;
	r200 = 1;
	#10;
	
	r200 = 0;
	r100 = 1;
	#10;
	//reset;
	
	rst = 1;
	 
	 #10;
	 rst = 0;
	 
	 #10;
	//fim
    // Finalizando a simulação
    $finish;
  end

endmodule