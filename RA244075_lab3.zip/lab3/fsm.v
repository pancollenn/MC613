// Quartus Prime Verilog Template
// 4-State Moore state machine

// A Moore machine's outputs are dependent only on the current state.
// The output is written only when the state changes.  (State
// transitions are synchronous.)

module fsm
(
	input	clk, rst, r50, r100, r200,
	output reg cafe, t50, t100, t200,
	output reg [3:0] out,
	output reg [3:0] state
);


	// Declare states
	parameter S0_base = 0, S1_50 = 1, S2_100 = 2, S3_150 = 3, S4_200 = 4,
				 S5_250 = 5, S6_300 = 6, S7_350 = 7, S8_400 = 8, S9_cafe = 9;

	// Output depends only on the state
always @ (state) begin

    case (state)
			
        S0_base: begin
				cafe = 0;
				t50 = 0;
				t100 = 0;
				t200 = 0;
				out = 4'd0;
			end
        S1_50: begin
				cafe = 0;
				t50 = 0;
				t100 = 0;
				t200 = 0;
            out = 4'd1;
				end
        S2_100: begin
				cafe = 0;
				t50 = 0;
				t100 = 0;
				t200 = 0;
            out = 4'd2;
				end
        S3_150: begin
				cafe = 0;
				t50 = 0;
				t100 = 0;
				t200 = 0;
            out = 4'd3;
				end	
        S4_200: begin
				cafe = 0;
				t50 = 0;
				t100 = 0;
				t200 = 0;
            out = 4'd4; 
				end
        S5_250: begin
				cafe = 0;
				t50 = 0;
				t100 = 0;
				t200 = 0;
            out = 4'd5; 
				end
        S6_300: begin
				cafe = 0;
				t100 = 0;
				t200 = 0;
				t50 = 1;
            out = 4'd6; 
		  end
        S7_350: begin
				cafe = 0;
				t50 = 0;
				t200 = 0;
				t100 = 1;
            out = 4'd7; 
		  end
        S8_400: begin
				cafe = 0;
				t50 = 1;
				t100 = 1;
				t200 = 0;
            out = 4'd8;
		  end
		  S9_cafe: begin
				t50 = 0;
				t100 = 0;
				t200 = 0;
				cafe = 1;
            out = 4'd9;
		  end
        //default:
          //  out = 4'd0; // 0 (reset)
    endcase
end


	// Determine the next state
	always @ (posedge clk or posedge rst) begin
		if (rst)
			state <= S0_base;

		else
			case (state)
				S0_base:
					begin
					
						//state <= S0_base;
						if(r50)
							state <= S1_50;
						else if(r100)
							state <= S2_100;
						else if(r200)
							state <= S4_200;
					end
				S1_50:
					begin
						if (r50)
							state <= S2_100;
						else if(r100)
							state <= S3_150;
						else if(r200)
							state <= S5_250;
					end
				S2_100:
					begin
						if (r50)
							state <= S3_150;
						else if(r100)
							state <= S4_200;
						else if(r200)
							state <= S6_300;
					end
				S3_150:
					begin
						if (r50)
							state <= S4_200;
						else if(r100)
							state <= S5_250;
						else if(r200)
							state <= S7_350;
					end
				S4_200:
					begin
						if (r50)
							state <= S5_250;
						else if(r100)
							state <= S6_300;
						else if(r200)
							state <= S8_400;
					end
					
				S5_250:
					begin
						state <= S9_cafe;
						end
						
				S6_300:
					begin
					
						state <= S9_cafe;
					end
					
				S7_350:
					begin
						
						state <= S9_cafe;
					end
				S8_400:
					begin
						
						state <= S9_cafe;
					end
				S9_cafe:
					begin
						state <= S0_base;
					end
						
			endcase
	end

	
endmodule
