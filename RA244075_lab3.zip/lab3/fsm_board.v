module fsm_board (
    input [3:0] KEY,
	 input [9:0] SW,
	 input CLOCK_50,
    // 7-segment displays (HEX5 to HEX0)
    output [6:0] HEX2,
    output [6:0] HEX1,
    output [6:0] HEX0,
	 output [9:0] LEDR

);
wire [3:0] out_b;
wire [3:0] state_b;


// FSM instantiation
fsm fsm1 (
	.clk(~KEY[3]),
	.rst(SW[0]),
	.r50(~KEY[2]),
	.r100(~KEY[1]),
	.r200(~KEY[0]),
	.cafe(LEDR[9]),
	.t50(LEDR[2]),
	.t100(LEDR[1]),
	.t200(LEDR[0]),
	.out(out_b),
	.state(state_b)
);

two_comp_to_7seg display (
	.abs_val(out_b),
	.segs1(HEX2),
	.segs2(HEX1),
	.segs3(HEX0)
);


endmodule