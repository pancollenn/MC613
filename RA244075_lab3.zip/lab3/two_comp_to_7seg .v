module two_comp_to_7seg (
    input [3:0] abs_val,       // 32-bit two's complement input
    output [6:0] segs1,     // 7-segment output (a=seg[6], g=seg[0])
	 output [6:0] segs2,     // 7-segment output (a=seg[6], g=seg[0])
	 output [6:0] segs3      // 7-segment output (a=seg[6], g=seg[0])
);

// 7-segment decoder (Common Cathode: 0=ON, 1=OFF)
assign segs1 = 
    (abs_val == 4'd0)  ? ~7'b0111111 :   // 000
    (abs_val == 4'd1)  ? ~7'b0111111 :   // 050
    (abs_val == 4'd2)  ? ~7'b0000110 :   // 100
    (abs_val == 4'd3)  ? ~7'b0000110 :   // 150
    (abs_val == 4'd4)  ? ~7'b1011011 :   // 200
    (abs_val == 4'd5)  ? ~7'b1011011 :   // 250
    (abs_val == 4'd6)  ? ~7'b1001111 :   // 300
    (abs_val == 4'd7)  ? ~7'b1001111 :   // 350
    (abs_val == 4'd8)  ? ~7'b1100110 :   // 400
	 (abs_val == 4'd9)  ? ~7'b1011011 :   // 250
    7'b1000000; 

	 assign segs2 = 
    (abs_val == 4'd0)  ? ~7'b0111111 :   // 0
    (abs_val == 4'd1)  ? ~7'b1101101 :   // 5
    (abs_val == 4'd2)  ? ~7'b0111111 :   // 0
    (abs_val == 4'd3)  ? ~7'b1101101 :   // 5
    (abs_val == 4'd4)  ? ~7'b0111111 :   // 0
    (abs_val == 4'd5)  ? ~7'b1101101 :   // 5
    (abs_val == 4'd6)  ? ~7'b0111111 :   // 0
    (abs_val == 4'd7)  ? ~7'b1101101 :   // 5
    (abs_val == 4'd8)  ? ~7'b0111111 :   // 0
    (abs_val == 4'd9)  ? ~7'b1101101 :   // 5
    7'b1000000;    
	 
	 assign segs3 = ~7'b0111111;
    

endmodule

