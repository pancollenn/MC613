module board (
    input [9:0] SW,
    output [31:0] A,
    output [31:0] B,
    output [1:0] ALUCtl,
    // ALU Results
    output [31:0] R,
    output Zero,
    output Cout,
    output Overflow,
    // 7-segment displays (HEX5 to HEX0)
    output [6:0] HEX5,
    output [6:0] HEX4,
    output [6:0] HEX3,
    output [6:0] HEX2,
    output [6:0] HEX1,
    output [6:0] HEX0,
	 output [9:0] LEDR
);

    // ===== Sign-extended A and B (4-bit inputs → 32-bit) =====
    assign A = (SW[7] == 0) ? {28'b0, SW[7:4]} : {28'b1, SW[7:4]};      
    assign B = (SW[3] == 0) ? {28'b0, SW[3:0]} : {28'b1, SW[3:0]};  
    assign ALUCtl = SW[9:8];  // ALU Control from SW[9:8]

    // ===== ALU Instantiation =====
    alu alu1 (
        .A(A),
        .B(B),
        .ALUCtl(ALUCtl),
        .R(R),
        .Zero(Zero),
        .Cout(Cout),
        .Overflow(Overflow)
    );

    // ===== 7-Segment Displays (4-bit values) =====
    wire [6:0] segs_A, segs_B, segs_R;
    wire neg_A, neg_B, neg_R;

    // Display for A (4 LSBs)
    two_comp_to_7seg A_display (
        .bin(A),
        .segs(segs_A),
        .neg(neg_A)
    );

    // Display for B (4 LSBs)
    two_comp_to_7seg B_display (
        .bin(B),
        .segs(segs_B),
        .neg(neg_B)
    );

    // Display for R (4 LSBs)
    two_comp_to_7seg R_display (
        .bin(R),
        .segs(segs_R),
        .neg(neg_R)
    );

    // ===== Connect HEX Displays =====
    // HEX5: Negative sign for A (if negative)
    assign HEX5 = neg_A ? 7'b0111111 : 7'b1111111;  // '-' or blank
    // HEX4: Value of A (4-bit)
    assign HEX4 = ~segs_A;

    // HEX3: Negative sign for B (if negative)
    assign HEX3 = neg_B ? 7'b0111111 : 7'b1111111;  // '-' or blank
    // HEX2: Value of B (4-bit)
    assign HEX2 = ~segs_B;

    // HEX1: Negative sign for R (if negative)
    assign HEX1 = neg_R ? 7'b0111111 : 7'b1111111;  // '-' or blank
    // HEX0: Value of R (4-bit)
    assign HEX0 = ~segs_R;
	 
	 assign LEDR[2] = Zero;
	 assign LEDR[1] = Overflow;
	 assign LEDR[0] = Cout;

endmodule