`timescale 10ns / 10ps

module alu_tb;

  // Entradas
  reg [31:0] A;
  reg [31:0] B;
  reg [1:0] ALUCtl;
  
  // Saídas
  wire [31:0] R;
  wire Zero;
  wire Overflow;
  wire Cout;

  // Instanciando o módulo ALU
  alu uut (
    .A(A),
    .B(B),
    .ALUCtl(ALUCtl),
    .R(R),
    .Zero(Zero),
    .Overflow(Overflow),
    .Cout(Cout)
  );
  integer i;
  // Inicializando o testbench
  initial begin
    // Exibindo os resultados no console
	 
    $monitor("A = %h, B = %h, ALUCtl = %b -> R = %h, Zero = %b, Overflow = %b, Cout = %b", A, B, ALUCtl, R, Zero, Overflow, Cout);
    
	 // Testando overflow em soma
    A = 32'h7FFFFFFF; B = 32'h00000001; ALUCtl = 2'b10; // Overflow na soma
    #10;
	 
	 // Testando overflow em subtração
    A = 32'h80000000; B = 32'h00000001; ALUCtl = 2'b11; // Overflow na subtração
    #10;
	 
    // Testando o caso 1: ALUCtl = 00 (Operação AND)
    A = 32'h12345678; B = 32'h9abcdef0; ALUCtl = 2'b00;
    #10; // Espera 10 unidades de tempo

    // Testando o caso 2: ALUCtl = 01 (Operação OR)
    A = 32'h12345678; B = 32'h9abcdef0; ALUCtl = 2'b01;
    #10;

    // Testando o caso 3: ALUCtl = 10 (Soma)
    A = 32'h00000001; B = 32'h00000001; ALUCtl = 2'b10;
    #10;

    // Testando o caso 4: ALUCtl = 11 (Subtração)
    A = 32'h00000002; B = 32'h00000001; ALUCtl = 2'b11;
    #10;

    // Testando casos extremos com 0 e 1
    A = 32'b0; B = 32'b0; ALUCtl = 2'b10; // Soma de zero
    #10;
	 
    A = 32'b0; B = 32'b0; ALUCtl = 2'b11; // Subtração de zero
    #10;
	 
	 //testando zero pela soma
	 A = 32'b0; B = 32'b0; ALUCtl = 2'b10;
	 #10;
	 
	 //testando zero por "AND"
	 A = 32'b0; B = 32'h23739; ALUCtl = 00;
	 
	 
	 // Testando alguns casos intermediarios de soma
	 for (i = 5; i < 5000; i = i + 1) begin
		#10
		A = i * 10;
		B = i * 5;
		ALUCtl = 2'b10;
	 end
	 
	 // Testando alguns casos intermediarios de subtracao
	 for (i = 5; i < 5000; i = i + 1) begin
		#10
		A = i * 10;
		B = i * 5;
		ALUCtl = 2'b11;
	 end

	 
    // Finalizando a simulação
    $finish;
  end

endmodule