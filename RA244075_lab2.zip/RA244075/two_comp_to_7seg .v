module two_comp_to_7seg (
    input [3:0] bin,       // 32-bit two's complement input
    output [6:0] segs,     // 7-segment output (a=seg[6], g=seg[0])
    output neg             // 1 if negative (bin[3] == 1)
);

// Negative flag (1 if MSB is set)
assign neg = bin[3];

// Absolute value (two's complement conversion if negative)
wire [3:0] abs_val = bin[3] ? (~bin + 1'b1) : bin;

// 7-segment decoder (Common Cathode: 0=ON, 1=OFF)
assign segs = 
    (abs_val == 4'd0)  ? 7'b0111111 :   // 0
    (abs_val == 4'd1)  ? 7'b0000110 :   // 1
    (abs_val == 4'd2)  ? 7'b1011011 :   // 2
    (abs_val == 4'd3)  ? 7'b1001111 :   // 3
    (abs_val == 4'd4)  ? 7'b1100110 :   // 4
    (abs_val == 4'd5)  ? 7'b1101101 :   // 5
    (abs_val == 4'd6)  ? 7'b1111101 :   // 6
    (abs_val == 4'd7)  ? 7'b0000111 :   // 7
    (abs_val == 4'd8)  ? 7'b1111111 :   // 8
    (abs_val == 4'd9)  ? 7'b1101111 :   // 9
    7'b1000000;                         // '-' (invalid/overflow)

endmodule