module alu(
	input [31: 0] A,
	input [31: 0] B,
	input [1: 0] ALUCtl, // operaçao a ser executada
	
	output reg [31: 0] R,
	output wire Zero,
	output wire Overflow,
	output wire Cout
);

	wire [31:0] soma;
	wire [31:0] subtracao;
	wire carry_out_soma;
	wire carry_out_sub;
	
	integer overflow_var;
	integer zero_var;
	integer cout_var;
	
	assign {carry_out_soma, soma} = A + B;
	assign {carry_out_subtracao, subtracao} = A - B;
	
	always @(*) begin
	
		overflow_var = 0;
		cout_var = 0;
		zero_var = 0;
		
		case (ALUCtl)
			2'b00: R = A & B;
			2'b10: R = A | B;
			2'b01: {cout_var ,R} = {carry_out_soma, soma};
			2'b11: {cout_var, R} = {carry_out_subtracao, subtracao};
		endcase

		if (R == 32'b0) begin
			zero_var = 1;
		end
		
	end
	
	assign Zero = zero_var;
	assign Overflow = overflow_var;
	assign Cout = cout_var;

endmodule