--Em que periféricos da placa DE1-SoC ela está conectada? 
--R.: LEDR, SW, HEX5 e KEY

--Por que a saída HEX5 foi declarado como um vetor 0 to 6 ao invés de 6 downto 0, como os demais?
--Que diferença faria uma declaração diferente no restante do código?
--R.: Porque HEX5 segue uma convençao que exige essa ordem. 0 to 6 representa que o bit menos significativo esta
--		a esquerda e 6 downto 0 representa que o bit menos significativo esta a direita. Dessa forma, inverter a ordem faria com que o display 
--		mostrasse caracteres incorretos.

--O que os valores atribuídos ao sinal HEX5 significam?
--R.: Se o segmento de certa posicao do display estar´a aceso ou nao.

--Qual a saída esperada (em valores binários) das saídas HEX5 e LEDR em função das entradas KEY e SW?
--R.: LEDR recebe o valor de SW. Dependendo da entrada KEY, HEX5 recebe um binario que corresponde a uma distribuicao de segmentos acesos no display.

--Qual o comportamento esperado do circuito quando gravado na placa DE1-SoC?
--R.: Se um switch for acionado, o led acima dele e aceso. As keys pressionadas resultam em um display com segmentos diferentes.

library ieee;
use ieee.std_logic_1164.all;

entity hexcode is
port (
  LEDR: out std_logic_vector(9 downto 0);
  SW: in std_logic_vector(9 downto 0);
  HEX5: out std_logic_vector(0 to 6);
  KEY: in std_logic_vector(3 downto 0)
  );
end entity hexcode;

architecture bhv of hexcode is
begin

  LEDR <= SW;
  
  with KEY select
  HEX5 <= "0000001" when "0000",
      "1001111" when "0001",
      "0010010" when "0010",
      "0000110" when "0011",
      "1001100" when "0100",
      "0100100" when "0101",
      "0100000" when "0110",
      "0001111" when "0111",
      "0000000" when "1000",
      "0000100" when "1001",
      "0001000" when "1010",
      "1100000" when "1011",
      "0110001" when "1100",
      "1000010" when "1101",
      "0110000" when "1110",
      "0111000" when "1111",
      "1111111" when others;

end architecture bhv;