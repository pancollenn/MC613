--Por que a entidade hexcode_tb não tem entradas e saídas?
--R.: Porque ele tem o objetivo de testar hexcode, e nao se comunica com o hardware externo.

--Como é feita a instanciação da entidade hexcode dentro do test bench? Por que não são usados pacotes (VHDL package) 
--e declaração de componentes (component)? O que significa a inscrição uut: e para que ela serve?
--R.: Utilizando o utt (unit under test), que e uma instaciacao de hexcode dentro do testbench. Pacotes e declaraçao de componentes nao sao utilizados
--		porque o testbench utiliza instanciacao direta das entidades.

--O que significa a palavra-chave work ao lado do nome da entidade instanciada?
--R.: Significa que a entidade pertence a biblioteca de trabalho, isto e, o local onde o compilador coloca todas as
-- 	entidades e arquiteturas do projeto.

--Qual a função dos pacotes std_logic_unsigned e numeric_std no código?
--R.:ieee.std_logic_unsigned.all permite operações aritméticas com std_logic_vector como se fossem números binários.
--		ieee.numeric_std.all fornece tipos unsigned e signed, além de funções para conversão.

--Qual o significado dos prefixo 'range, 'length e 'event nos sinais sw, keys e clock e por que eles são usados?
--R.: range retorna o intervalo de ´indices de um vetor. length retorna o numero de elementos de um vetor
--		event retorna se houve mudanca no valor do sinal.

--Quais são os padrões de entrada aplicados aos sinais SW e KEY?
--R.: SW espera um vetor de 10 bits, indo do indice 9 ao 0. KEY espera um vetor de 4 bits, indo do indice 3 ao 0. 

--Quais são as saídas esperadas para o teste?
--R.: LEDR espera um vetor de 10 bits, indo do indice 9 ao 0. HEX5 espera um vetor de 7 bits, que mapeia um display de 7 segmentos


library ieee;
use ieee.std_logic_1164.all;
use ieee.std_logic_unsigned.all;
use ieee.numeric_std.all;

entity hexcode_tb is
end entity hexcode_tb;

architecture tb of hexcode_tb is
  signal leds: std_logic_vector(9 downto 0);
  signal sw: std_logic_vector(9 downto 0) := (others => '0');
  signal hex: std_logic_vector(0 to 6);
  signal keys: std_logic_vector(3 downto 0) := (others => '0');
  
  signal clock: std_logic := '0';
  signal stop: std_logic;
begin

  uut: entity work.hexcode port map(LEDR => leds, SW => sw, HEX5 => hex, KEY => keys);
  
  clock <= not clock after 5 ns when stop = '0' else '0';
  stop <= '1' when sw = (sw'range => '1') and keys = (keys'range => '1') else '0';
  
  process(clock)
  begin
    if clock'event and clock = '1' and stop = '0' then
      sw <= std_logic_vector(to_unsigned(to_integer(unsigned(sw)) + 1, sw'length));
      keys <= std_logic_vector(to_unsigned(to_integer(unsigned(keys)) + 1, keys'length));
    end if;
  end process;
end architecture tb;