library ieee;
use ieee.std_logic_1164.all;
use ieee.std_logic_unsigned.all;

entity ledshift is
    port (
        CLOCK_50 : in std_logic;
        KEY   : in std_logic_vector(3 downto 0);
        LEDR  : out std_logic_vector(9 downto 0)
    );
end entity ledshift;

architecture bhv of ledshift is
    signal position : integer range 0 to 9 := 5;
    signal led_output : std_logic_vector(9 downto 0);
	 signal estado_led : std_logic_vector(9 downto 0) := "0000010000";
	 signal estado_key0, estado_key3 : std_logic := '0';
	 
begin
    process(CLOCK_50)
    begin
        if rising_edge(CLOCK_50) then
            if KEY(3) = '0' and position < 9 and estado_key3 = '0' then
                position <= position + 1;
					 estado_key3 <= '1';
					 
            elsif KEY(3) = '1' then
					estado_key3 <= '0';
					end if;
				
				if KEY(0) = '0' and position > 0 and estado_key0 = '0' then
                position <= position - 1;
					 estado_key0 <= '1';
				
				elsif KEY(0) = '1' then
					estado_key0 <= '0';	
               end if;
        end if;
    end process;

    process(position)
    begin
        led_output <= (others => '0');  -- Garante que apenas um LED está aceso
        led_output(position) <= '1';
    end process;

    LEDR <= led_output;

end architecture bhv;
