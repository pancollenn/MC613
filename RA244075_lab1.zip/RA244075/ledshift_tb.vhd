library ieee;
use ieee.std_logic_1164.all;
use ieee.std_logic_unsigned.all;
use ieee.numeric_std.all;

entity ledshift_tb is
end entity ledshift_tb;

architecture tb of ledshift_tb is
    signal clock: std_logic := '0';
    signal keys: std_logic_vector(3 downto 0) := (others => '1');
    signal leds: std_logic_vector(9 downto 0);
    signal stop: std_logic;
    signal press_count_0: integer := 0;
    signal press_count_3: integer := 0;
    signal state: std_logic := '0'; -- 0: pressionando, 1: soltando

begin
    -- Instância do DUT
    uut: entity work.ledshift port map(CLOCK_50 => clock, KEY => keys, LEDR => leds);

    -- Geração de clock (10 ns de período)
    clock <= not clock after 5 ns when stop = '0' else '0';
    
    -- Condição de parada
    stop <= '1' when (press_count_0 = 10 and press_count_3 = 10) else '0';

    -- Processo de estímulo
    process(clock)
    begin
        if rising_edge(clock) and stop = '0' then
            if state = '0' then  -- Pressionar tecla
                if press_count_3 < 10 then
                    keys(3) <= '0';
                elsif press_count_0 < 10 then
                    keys(0) <= '0';
                end if;
                state <= '1';  -- Muda para soltar a tecla no próximo ciclo
            else  -- Soltar tecla
                if press_count_3 < 10 then
                    keys(3) <= '1';
                    press_count_3 <= press_count_3 + 1;
                elsif press_count_0 < 10 then
                    keys(0) <= '1';
                    press_count_0 <= press_count_0 + 1;
                end if;
                state <= '0';  -- Muda para pressionar no próximo ciclo
            end if;
        end if;
    end process;
    
end architecture tb;
