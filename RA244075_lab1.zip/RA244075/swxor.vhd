library ieee;
use ieee.std_logic_1164.all;
use ieee.numeric_std.all;

entity swxor is
port (
  LEDR: out std_logic_vector(9 downto 0);
  SW: in std_logic_vector(9 downto 0)
  );
end entity swxor;

architecture bhv of swxor is
begin

  LEDR(9) <= '0';
  LEDR(0) <= SW(0) xor SW(1);
  LEDR(1) <= SW(1) xor SW(2);
  LEDR(2) <= SW(2) xor SW(3);
  LEDR(3) <= SW(3) xor SW(4);
  LEDR(4) <= SW(4) xor SW(5);
  LEDR(5) <= SW(5) xor SW(6);
  LEDR(6) <= SW(6) xor SW(7);
  LEDR(7) <= SW(7) xor SW(8);
  LEDR(8) <= SW(8) xor SW(9);
  

end architecture bhv;